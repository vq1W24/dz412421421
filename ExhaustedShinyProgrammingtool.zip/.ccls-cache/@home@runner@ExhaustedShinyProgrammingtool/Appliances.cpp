#include "Appliances.h"
#include <iostream>
using namespace std;

Appliances::Appliances(int weight)
    : weight(weight) {}

void Appliances::SetWeight(int weight) {
    this->weight = weight;
}

int Appliances::GetWeight() const {
    return weight;
}

void Appliances::ShowSpec() const {
    cout << "Weight: " << weight << " kg" << endl;
}