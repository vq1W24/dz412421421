#ifndef IELECTRONICS_H
#define IELECTRONICS_H


class IElectronics {
public:
    virtual ~IElectronics() {}

    virtual void ShowSpec() const = 0;
};

#endif 