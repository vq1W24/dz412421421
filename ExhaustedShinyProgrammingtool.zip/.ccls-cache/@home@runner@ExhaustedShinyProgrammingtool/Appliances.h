#ifndef APPLIANCES_H
#define APPLIANCES_H

#include "IElectronics.h"

class Appliances : public IElectronics {
public:
    Appliances(int weight);

    void SetWeight(int weight);
    int GetWeight() const;

    void ShowSpec() const override;

private:
    int weight;
};

#endif 