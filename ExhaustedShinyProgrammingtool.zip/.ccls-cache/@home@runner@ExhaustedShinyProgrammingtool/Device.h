#ifndef DEVICE_H
#define DEVICE_H
#include <string>
using namespace std;

class Device 
{
public:
    Device(string model, string manufacturer);
    virtual ~Device();

    void SetModel(string model);
    string GetModel() const;

    void SetManufacturer(string manufacturer);
    string GetManufacturer() const;

    virtual void ShowSpec() const = 0;

private:
    string model;
    string manufacturer;
};

#endif 