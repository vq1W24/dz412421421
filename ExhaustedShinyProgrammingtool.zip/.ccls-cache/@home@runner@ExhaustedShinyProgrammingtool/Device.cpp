#include "Device.h"
using namespace std;
Device::Device(string model, string manufacturer)
    : model(model), manufacturer(manufacturer) {}

Device::~Device() {}

void Device::SetModel(string model) {
    this->model = model;
}

string Device::GetModel() const {
    return model;
}

void Device::SetManufacturer(string manufacturer) {
    this->manufacturer = manufacturer;
}

string Device::GetManufacturer() const {
    return manufacturer;
}