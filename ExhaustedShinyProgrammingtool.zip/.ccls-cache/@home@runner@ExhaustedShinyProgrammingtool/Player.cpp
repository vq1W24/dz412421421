#include "Player.h"
#include <iostream>
using namespace std;
Player::Player(string model, string manufacturer, int batteryLife, int trackCount)
    : Device(model, manufacturer), batteryLife(batteryLife), trackCount(trackCount) {}

void Player::SetBatteryLife(int batteryLife) {
    this->batteryLife = batteryLife;
}

int Player::GetBatteryLife() const {
    return batteryLife;
}

void Player::SetTrackCount(int trackCount) {
    this->trackCount = trackCount;
}

int Player::GetTrackCount() const {
    return trackCount;
}

void Player::ShowSpec() const {
    cout << "Battery Life: " << batteryLife << " hours" << endl;
    cout << "Track Count: " << trackCount << endl;
}