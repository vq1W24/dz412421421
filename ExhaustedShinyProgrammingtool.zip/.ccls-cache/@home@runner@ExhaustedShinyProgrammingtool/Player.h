#ifndef PLAYER_H
#define PLAYER_H

#include "Device.h"
using namespace std;

class Player : public Device {
public:
    Player(string model, string manufacturer, int batteryLife, int trackCount);

    void SetBatteryLife(int batteryLife);
    int GetBatteryLife() const;

    void SetTrackCount(int trackCount);
    int GetTrackCount() const;

    void ShowSpec() const override;

private:
    int batteryLife;
    int trackCount;
};

#endif // PLAYER_H


